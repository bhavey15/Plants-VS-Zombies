package application;
import java.io.*;
public class Player implements Serializable {
	
	Player(String name){
		
		this.name=name;
		level=new Level();
		level.setLevel(1);
	}
	private final static long serialVersionUID = 17L;
	private int sunscore;
	private Level level;
	private String name;
	public int getSunscore() {
		return sunscore;
	}
	public void setSunscore(int sunscore) {
		this.sunscore = sunscore;
	}
	public Level getLevel() {
		return level;
	}
	public void setLevel(Level level) {
		this.level = level;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHelp() {
		String s= "Instruction Set";
		return s;	
	}
	

}
