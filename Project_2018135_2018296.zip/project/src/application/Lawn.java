package application;

import java.io.*;
import java.util.*;

public class Lawn implements Serializable {
	private final static long serialVersionUID = 16L;
//	ArrayList<Zombie> zombies = new ArrayList<Zombie>();
	ArrayList<Plant> plants = new ArrayList<Plant>();
	public void addPlant(Plant x) {
		plants.add(x);
	}
	
}

class Lawnmower{
	boolean activated;
	public void move() {
		if(activated==true) {
			
		}
		
	}
}
