package application;
import javafx.animation.Timeline;
import javafx.animation.Transition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
//			Game game = new Game();
			primaryStage.setTitle("Plants V/S Zombies");
			AudioClip music = new AudioClip(getClass().getResource("/resources/animals.mp3").toExternalForm());
			music.setCycleCount(Timeline.INDEFINITE);
//			MediaPlayer player = new MediaPlayer(music);
			music.play();
//			getClass().getResource("").toExternalForm()
			Pane root= new GridPane();
			VBox buttons = new VBox(4);
			BackgroundSize s= new BackgroundSize(1000, 600, false, false, false,false);
			Background bg= new Background(new BackgroundImage(new Image("/resources/start.jpg"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,s));
			root.setBackground(bg);
//			buttons.setBackground(new Background(new BackgroundImage(new Image("/resources/wood1.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER, new BackgroundSize(100, 100,false,false,false,false))));
			Background butt_bg= new Background(new BackgroundImage(new Image("/resources/wood1.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER, new BackgroundSize(100, 40,false,false,false,false)));
			Button butt1 = new Button("Start Game");
			
			butt1.setBackground(butt_bg);
			butt1.setTextFill(Paint.valueOf("#ffffff"));
			butt1.setPrefSize(100, 40);
			Button butt2 = new Button("Load Game");
			butt2.setBackground(butt_bg);
			butt2.setTextFill(Paint.valueOf("#ffffff"));
			butt2.setPrefSize(100, 40);
			Button butt3 = new Button("Choose Level");
			butt3.setBackground(butt_bg);
			butt3.setTextFill(Paint.valueOf("#ffffff"));
			butt3.setPrefSize(100, 40);
			Button butt4 = new Button("Exit");
			butt4.setOnAction(e->{
				music.stop();
				primaryStage.close();
			});
			butt4.setBackground(butt_bg);
			butt4.setTextFill(Paint.valueOf("#ffffff"));
			butt4.setPrefSize(100, 40);
			buttons.getChildren().add(butt1);
			buttons.getChildren().add(butt2);
			buttons.getChildren().add(butt3);
			buttons.getChildren().add(butt4);
			buttons.setAlignment(Pos.CENTER);
			root.getChildren().add(buttons);

			GridPane root2= new GridPane();
			Scene mainscene = new Scene(root,1000,600);
			bg = new Background(new BackgroundImage(new Image("/resources/lawn.jpg"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,s));
			root2.setBackground(bg);
			Scene scene2 = new Scene(root2,1000,600);
			primaryStage.setScene(mainscene);
			Button plant1= new Button();
			Button plant2= new Button();
			Button plant3= new Button();
			Button plant4 = new Button();
			int sunscore=0;
			Label l= new Label("     Your \n       Sunscore :\n     "+sunscore);
			l.setPrefSize(100, 100);
			l.setTextAlignment(TextAlignment.CENTER);
			l.setBackground(new Background(new BackgroundImage(new Image("/resources/sun.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(100,100,false,false,false,false))));
			plant2.setPrefHeight(75);
			plant2.setPrefWidth(75);
			plant3.setPrefHeight(75);
			plant3.setPrefWidth(75);
			plant1.setPrefHeight(75);
			plant1.setPrefWidth(75);
			plant4.setPrefHeight(75);
			plant4.setPrefWidth(75);
			HBox menubar =  new HBox();
			Button menu = new Button("Game Menu");
			menubar.getChildren().add(menu);
			menu.setBackground(new Background(new BackgroundImage(new Image("/resources/wood1.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(100,40,false,false,false,false))));
			menu.setTextFill(Paint.valueOf("#ffffff"));
			menubar.setAlignment(Pos.TOP_RIGHT);
			root2.getChildren().add(menubar);
			Pane root3= new GridPane();
			root3.setBackground(new Background(new BackgroundImage(new Image("/resources/start.jpg"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(1000,600,false,false,false,false))));
			Button list1= new Button("Save Game");
			Button list2= new Button("Exit Game");
			Button list3= new Button("Resume Game");
			Button list4= new Button("Go to Main Menu");
			list1.setTextFill(Paint.valueOf("#ffffff"));
			list2.setTextFill(Paint.valueOf("#ffffff"));
			list3.setTextFill(Paint.valueOf("#ffffff"));
			list4.setTextFill(Paint.valueOf("#ffffff"));
			list1.setFont(Font.font(30));
			list2.setFont(Font.font(30));
			list3.setFont(Font.font(30));
			list4.setFont(Font.font(30));
			list1.setBackground(new Background(new BackgroundImage(new Image("/resources/wood.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(300,150,false,false,false,false))));
			list2.setBackground(new Background(new BackgroundImage(new Image("/resources/wood.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(300,150,false,false,false,false))));
			list3.setBackground(new Background(new BackgroundImage(new Image("/resources/wood.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(300,150,false,false,false,false))));
			list4.setBackground(new Background(new BackgroundImage(new Image("/resources/wood.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(3000,150,false,false,false,false))));
			ImageView im = new ImageView(new Image("/resources/zombie.gif"));
			ImageView lawnmower1= new ImageView(new Image("/resources/lawnmower.png"));
			ImageView lawnmower2= new ImageView(new Image("/resources/lawnmower.png"));
			ImageView lawnmower3= new ImageView(new Image("/resources/lawnmower.png"));
			ImageView lawnmower4= new ImageView(new Image("/resources/lawnmower.png"));
			ImageView lawnmower5= new ImageView(new Image("/resources/lawnmower.png"));
			ImageView peashoot = new ImageView(new Image("/resources/peashooter.gif"));
			ImageView sunflower = new ImageView(new Image("/resources/sunflower.gif"));
//			ImageView sun = new ImageView(new Image("/resources/sun.png"));
			GridPane lawn = new GridPane();
			Circle pea = new Circle();
			pea.setRadius(8.0);
			pea.setTranslateX(-200);
			pea.setTranslateY(-15);
			pea.setFill(Paint.valueOf("#00ff00"));
			im.setFitHeight(100);
			im.setFitWidth(75);
//			sun.setFitHeight(75);
//			sun.setFitWidth(75);
//			root2.getChildren().add(sun);
			lawnmower1.setFitHeight(100);
			lawnmower1.setFitWidth(75);
			lawnmower2.setFitHeight(100);
			lawnmower2.setFitWidth(75);
			lawnmower3.setFitHeight(100);
			lawnmower3.setFitWidth(75);
			lawnmower4.setFitHeight(100);
			lawnmower4.setFitWidth(75);
			lawnmower5.setFitHeight(100);
			lawnmower5.setFitWidth(75);
			peashoot.setFitHeight(50);
			peashoot.setFitWidth(50);
			sunflower.setFitHeight(50);
			sunflower.setFitWidth(50);
			lawn.setVgap(15);
			lawn.setHgap(35);
			lawn.add(im, 14, 3);
			lawn.add(lawnmower1, 4, 1);
			lawn.add(lawnmower2, 4, 2);
			lawn.add(lawnmower3, 4, 3);
			lawn.add(lawnmower4, 4, 4);
			lawn.add(lawnmower5, 4, 5);
			lawn.add(peashoot, 5, 3);
			lawn.add(sunflower, 5, 2);
			root2.getChildren().add(pea);
//			lawn.add(pea,7,3);
			root2.getChildren().add(lawn);
			VBox  menulist = new VBox(3);
			menulist.getChildren().add(list1);
			list1.setPrefSize(500, 80);
			list2.setPrefSize(500,80);
			list3.setPrefSize(500,80);
			list4.setPrefSize(500,80);
			menulist.getChildren().add(list2);
			menulist.getChildren().add(list3);
			menulist.getChildren().add(list4);
			root3.getChildren().add(menulist);
			list4.setOnAction(e->{
				primaryStage.setScene(mainscene);
			});
			Scene scene3= new Scene(root3, 1000,600);
			menulist.setAlignment(Pos.CENTER);
			bg = new Background(new BackgroundImage(new Image("/resources/pea.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));
			plant1.setBackground(bg);
			bg = new Background(new BackgroundImage(new Image("/resources/sunflower.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));
			plant2.setBackground(bg);
			bg = new Background(new BackgroundImage(new Image("/resources/potato.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));

			plant3.setBackground(bg);
			bg = new Background(new BackgroundImage(new Image("/resources/walnut.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));
			plant4.setBackground(bg);
			VBox plants = new VBox(5);
			plants.getChildren().add(l);
			plants.getChildren().add(plant1);
			plants.getChildren().add(plant2);
			plants.getChildren().add(plant3);
			plants.getChildren().add(plant4);
			plants.setAlignment(Pos.TOP_LEFT);
			root2.getChildren().add(plants);
//			Button 
			butt1.setOnMousePressed(e->{
				primaryStage.setScene(scene2);
				TranslateTransition translateTransition = new TranslateTransition(); 
				translateTransition.setDuration(Duration.millis(15000)); 
				translateTransition.setNode(im);
				translateTransition.setByX(-500);
				translateTransition.setCycleCount(Timeline.INDEFINITE);
				translateTransition.setAutoReverse(false);
				translateTransition.play(); 
				TranslateTransition translateTransition2 = new TranslateTransition(); 
				translateTransition2.setDuration(Duration.millis(1500));
				translateTransition2.setNode(pea);
				translateTransition2.setByX(350);
				translateTransition2.setCycleCount(Timeline.INDEFINITE);
				translateTransition2.setAutoReverse(false);
				translateTransition2.play(); 
			});
			menu.setOnKeyPressed(e->{
				if(e.getCode()==KeyCode.A)
				primaryStage.setScene(scene3);
			});
			list3.setOnMouseClicked(e->{
				primaryStage.setScene(scene2);
			});
			primaryStage.show();
			GridPane login = new GridPane();
			login.setBackground(bg);
			Label username = new Label("Enter Username");
			Button forward= new Button("Login");
			TextField user = new TextField();
			Scene scene= new Scene(login,1000,600);
			login.setVgap(10);
			login.setHgap(10);
			login.add(username, 31, 30);
			login.add(user, 32, 30);
			login.add(forward, 32 , 31);
			//levelscreen
			GridPane lscreen = new GridPane();
			lscreen.setBackground(bg);
			Scene scenel = new Scene(lscreen,1000,600);
			HBox levels = new HBox(5);
			Button level1 = new Button("Level 1");
			Button level2 = new Button("Level 2");
			Button level3 = new Button("Level 3");
			Button level4 = new Button("Level 4");
			Button level5 = new Button("Level 5");
			levels.getChildren().add(level1);
			levels.getChildren().add(level2);
			levels.getChildren().add(level3);
			levels.getChildren().add(level4);
			levels.getChildren().add(level5);
			lscreen.add(levels, 0, 0);
//			forward.setOnAction(new EventHandler<ActionEvent>(){
//				@Override
//				public void handle(ActionEvent event) {
//					Player p= new Player(user.getText());
//					game.players.add(p);
//					primaryStage.setScene(scenel);
//				}
//			});
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
