package application;
import java.io.*;
import java.util.*;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;
public class Level implements Serializable {
	Level(){
		lawn=new Lawn();
	}
	ImageView pea = new ImageView(new Image("/resources/bullet.png"));
	private final static long serialVersionUID = 19L;
	private int level;
	ArrayList<Zombie> zombies = new ArrayList<Zombie>();//Composite DP
	ArrayList<ImageView> zimages = new ArrayList<ImageView>();
	private int flags[]= new int[5];
	private Sidebar sidebar;
	private Lawn lawn;
	public Sidebar getSidebar() {
		return sidebar;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public void setSidebar(Sidebar sidebar) {
		this.sidebar = sidebar;
	}
	public Lawn getLawn() {
		return lawn;
	}
	public void setLawn(Lawn lawn) {
		this.lawn = lawn;
	}
	public void generatezombies() {
		Random random= new Random();
		ImageView norm = new ImageView(new Image("/resources/zombie.gif"));
		ImageView buck = new ImageView(new Image("/resources/buckie.gif"));

		norm.setFitHeight(75);
		norm.setFitWidth(75);
		buck.setFitHeight(75);
		buck.setFitWidth(75);
		Zombie z1 = new Normie(norm);
		Zombie z2 = new Buckie(buck);
		for(int i=0;i<5;i++) {
			zombies.add((Normie)ZombieLab.getclone(z1));
		}
		if(level==2)
		for(int i=0;i<3;i++) {
			int x= random.nextInt(2);
			if(x==0) {
				zombies.add((Normie)ZombieLab.getclone(z1));
			}
			if(x==1) {
				zombies.add((Buckie)ZombieLab.getclone(z2));
			}
		}
		if(level==3)
		for(int i=0;i<5;i++) {
			int x= random.nextInt(2);
			if(x==0) {
				zombies.add((Normie)ZombieLab.getclone(z1));
			}
			if(x==1) {
				zombies.add((Buckie)ZombieLab.getclone(z2));
			}
		}
		if(level==4)
			for(int i=0;i<7;i++) {
				int x= random.nextInt(2);
				if(x==0) {
					zombies.add((Normie)ZombieLab.getclone(z1));
				}
				if(x==1) {
					zombies.add((Buckie)ZombieLab.getclone(z2));
				}
			}
		if(level==5)
			for(int i=0;i<10;i++) {
				int x= random.nextInt(2);
				if(x==0) {
					zombies.add((Normie)ZombieLab.getclone(z1));
				}
				if(x==1) {
					zombies.add((Buckie)ZombieLab.getclone(z2));
				}
			}
		
	}
	public void setLevelScreen(Pane root2, Player player,Stage primaryStage) {
		ImageView peashoo = new ImageView(new Image("/resources/pea.png"));
		ImageView potato = new ImageView(new Image("/resources/potato.png"));
		ImageView walnut = new ImageView(new Image("/resources/walnut.png"));
		ImageView sunfl = new ImageView(new Image("/resources/sunflower.png"));
		Plant p=new Peashooter(peashoo);
		lawn.addPlant(p);
		p= new Sunflower(sunfl);
		lawn.addPlant(p);
		this.generatezombies();
		if(level==2) {
			p= new Potatomine(potato);
			lawn.addPlant(p);
			sidebar.plants.add(p);
		}
		if(level ==3) {
			p= new Potatomine(potato);
			lawn.addPlant(p);
			p= new Walnut(walnut);
			lawn.addPlant(p);
		}
		if(level==4) {
			p= new Potatomine(potato);
			lawn.addPlant(p);
			p= new Walnut(walnut);
			lawn.addPlant(p);
		}
		if(level==5) {
			p= new Potatomine(potato);
			lawn.addPlant(p);
			p= new Walnut(walnut);
			lawn.addPlant(p);
			this.generatezombies();
		}
	Background bg;
	bg = new Background(new BackgroundImage(new Image("/resources/lawn.jpg"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(1000,600,false,false,false,false)));

	root2.setBackground(bg);
//	Scene scene = new Scene(root2,1000,600);
	Button plant1= new Button();
	Button plant2= new Button();
//	Button plant4 = new Button();
	Label l= new Label("     Your \n       Sunscore :\n     "+player.getSunscore());
	l.setPrefSize(100, 100);
	l.setTextAlignment(TextAlignment.CENTER);
	l.setBackground(new Background(new BackgroundImage(new Image("/resources/sun.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(100,100,false,false,false,false))));
	plant2.setPrefHeight(75);
	plant2.setPrefWidth(75);
	plant1.setPrefHeight(75);
	plant1.setPrefWidth(75);
//	plant4.setPrefHeight(75);
//	plant4.setPrefWidth(75);
	Button menu = new Button("Game Menu");
	menu.setBackground(new Background(new BackgroundImage(new Image("/resources/wood1.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(100,40,false,false,false,false))));
	menu.setTextFill(Paint.valueOf("#ffffff"));
//	ImageView im = new ImageView(new Image("/resources/zombie.gif"));
	ImageView lawnmower1= new ImageView(new Image("/resources/lawnmower.png"));
	ImageView lawnmower2= new ImageView(new Image("/resources/lawnmower.png"));
	ImageView lawnmower3= new ImageView(new Image("/resources/lawnmower.png"));
	ImageView lawnmower4= new ImageView(new Image("/resources/lawnmower.png"));
	ImageView lawnmower5= new ImageView(new Image("/resources/lawnmower.png"));
	GridPane lawn = new GridPane();
//	ImageView pea = new ImageView(new Image("/resources/bullet.png"));
//	im.setFitHeight(75);
//	im.setFitWidth(75);
	lawnmower1.setFitHeight(75);
	lawnmower1.setFitWidth(75);
	lawnmower2.setFitHeight(75);
	lawnmower2.setFitWidth(75);
	lawnmower3.setFitHeight(75);
	lawnmower3.setFitWidth(75);
	lawnmower4.setFitHeight(75);
	lawnmower4.setFitWidth(75);
	lawnmower5.setFitHeight(75);
	lawnmower5.setFitWidth(75);
//	lawn.add(im, 20, 3);
	lawn.setVgap(20);
	lawn.setHgap(20);
	lawn.add(lawnmower1, 6, 2);
	lawn.add(lawnmower2, 6, 3);
	lawn.add(lawnmower3, 6, 4);
	lawn.add(lawnmower4, 6, 5);
	lawn.add(lawnmower5, 6, 6);
//	lawn.add(pea,1,0);
	root2.getChildren().add(lawn);
	bg = new Background(new BackgroundImage(new Image("/resources/pea.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));
	plant1.setBackground(bg);
	bg = new Background(new BackgroundImage(new Image("/resources/sunflower.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));
	plant2.setBackground(bg);
//	bg = new Background(new BackgroundImage(new Image("/resources/walnut.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));
//	plant4.setBackground(bg);
	VBox plants = new VBox(6);
	plants.getChildren().add(l);
	plants.getChildren().add(plant1);
	plants.getChildren().add(plant2);
	if(level>=2) {
		Button plant3= new Button();
		plant3.setPrefHeight(75);
		plant3.setPrefWidth(75);
		bg = new Background(new BackgroundImage(new Image("/resources/walnut.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));
		plant3.setBackground(bg);
		plants.getChildren().add(plant3);
		plant3.setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent e) {
				root2.getScene().setOnMouseReleased(new EventHandler<MouseEvent>() {
					boolean m=true;
					@Override
					public void handle(MouseEvent e) {
						if(m==true) {
							ImageView dragged = new ImageView(new Image("/resources/walnut.gif"));
							dragged.setFitHeight(50);
							dragged.setFitWidth(50);
							double x_cor=e.getSceneX();
							double y_cor=e.getSceneY();
							dragged.setLayoutX(x_cor-25);
							dragged.setLayoutY(y_cor-30);
							root2.getChildren().add(dragged);
							m=false;
						}
					}
				});
			}
		});
	}
	if(level>=3) {
		Button plant4= new Button();
		plant4.setPrefHeight(75);
		plant4.setPrefWidth(75);
		bg = new Background(new BackgroundImage(new Image("/resources/potato.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(75,75,false,false,false,false)));
		plant4.setBackground(bg);
		plants.getChildren().add(plant4);
	}
	plants.getChildren().add(menu);
	plants.setAlignment(Pos.TOP_LEFT);
	root2.getChildren().add(plants);
	for(int i=0;i<zombies.size();i++) {
		ImageView v= zombies.get(i).image;
		zimages.add(v);
		v.setFitHeight(100);
		v.setFitWidth(100);
		v.setLayoutX(650);
		v.setLayoutY(50+i*100);
		if(zombies.get(i).getClass()==Normie.class) {
			root2.getChildren().add(v);
		}
		if(zombies.get(i).getClass()==Buckie.class) {
			root2.getChildren().add(v);
		}
	}
	pea.boundsInParentProperty().addListener((observable, oldvalue, newvalue)->checkit());
	plant1.setOnMousePressed(new EventHandler<MouseEvent>(){
		@Override
		public void handle(MouseEvent e) {
			root2.getScene().setOnMouseReleased(new EventHandler<MouseEvent>() {
				boolean m=true;
				@Override
				public void handle(MouseEvent e) {
					if(m==true) {
						ImageView dragged = new ImageView(new Image("/resources/peashooter.gif"));
//						Circle pea = new Circle();
//						pea.setRadius(8.0);
//						pea.setFill(Paint.valueOf("#00ff00"));
						dragged.setFitHeight(50);
						dragged.setFitWidth(50);
						double x_cor=e.getSceneX();
						double y_cor=e.getSceneY();
						dragged.setLayoutX(x_cor-25);
						dragged.setLayoutY(y_cor-30);
						pea.setTranslateX(x_cor);
						pea.setTranslateY(y_cor-25);
						root2.getChildren().add(dragged);
						m=false;
						KeyFrame kf = new KeyFrame(Duration.millis(1500), new TimeHandler(pea, flags));
						Timeline timeline = new Timeline(kf);
						timeline.setCycleCount(Animation.INDEFINITE);
						timeline.play();
						TranslateTransition translateTransition2 = new TranslateTransition(); 
						root2.getChildren().add(pea);
						translateTransition2.setDuration(Duration.millis(1500));
						translateTransition2.setNode(pea);
						translateTransition2.setByX(500);
						translateTransition2.setCycleCount(Timeline.INDEFINITE);
						translateTransition2.setAutoReverse(false);
						translateTransition2.play();
						
						
					}
				}
			});
		}
	});
	Pane root3= new GridPane();
	root3.setBackground(new Background(new BackgroundImage(new Image("/resources/start.jpg"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(1000,600,false,false,false,false))));
	Button list1= new Button("Save Game");
	Button list2= new Button("Exit Game");
	Button list3= new Button("Resume Game");
	Button list4= new Button("Go to Main Menu");
	list2.setOnAction(e->{
		primaryStage.close();
	});
	list3.setOnAction(e->{
		primaryStage.setScene(root2.getScene());
	});
	list1.setTextFill(Paint.valueOf("#ffffff"));
	list2.setTextFill(Paint.valueOf("#ffffff"));
	list3.setTextFill(Paint.valueOf("#ffffff"));
	list4.setTextFill(Paint.valueOf("#ffffff"));
	list1.setFont(Font.font(30));
	list2.setFont(Font.font(30));
	list3.setFont(Font.font(30));
	list4.setFont(Font.font(30));
	list1.setBackground(new Background(new BackgroundImage(new Image("/resources/wood.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(300,150,false,false,false,false))));
	list2.setBackground(new Background(new BackgroundImage(new Image("/resources/wood.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(300,150,false,false,false,false))));
	list3.setBackground(new Background(new BackgroundImage(new Image("/resources/wood.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(300,150,false,false,false,false))));
	list4.setBackground(new Background(new BackgroundImage(new Image("/resources/wood.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize(300,150,false,false,false,false))));
	HBox list = new HBox(4);
	list.getChildren().add(list1);
	list.getChildren().add(list2);
	list.getChildren().add(list3);
	list.getChildren().add(list4);
	root3.getChildren().add(list);
	
	Scene sc= new Scene(root3,1000,600);
	menu.setOnAction(e->{
		primaryStage.setScene(sc);
	});
	plant2.setOnMousePressed(new EventHandler<MouseEvent>(){
		@Override
		public void handle(MouseEvent e) {
			root2.getScene().setOnMouseReleased(new EventHandler<MouseEvent>() {
				boolean m=true;
				@Override
				public void handle(MouseEvent e) {
					if(m==true) {
						ImageView dragged = new ImageView(new Image("/resources/sunflower.gif"));
						dragged.setFitHeight(50);
						dragged.setFitWidth(50);
						double x_cor=e.getSceneX();
						double y_cor=e.getSceneY();
						dragged.setLayoutX(x_cor-25);
						dragged.setLayoutY(y_cor-30);
						root2.getChildren().add(dragged);
						m=false;
					}
				}
			});
		}
	});
}
public void checkit() {
	for(int i=0;i<zimages.size();i++) {
		if(pea.getBoundsInParent().intersects(zimages.get(i).getBoundsInParent())&&flags[i]==1) {
			System.out.println(zombies.get(i).getHealth());
			zombies.get(i).setHealth(zombies.get(i).getHealth()-2);
			pea.setVisible(false);
			flags[i]=0;
		}
		if(zombies.get(i).getHealth()<=0) {
			zimages.get(i).setVisible(false);
			pea.setVisible(true);
		}
	}
}

}
class Sidebar{
	ArrayList<Plant> plants = new ArrayList<Plant>();
	Label sunscore =  new Label();
	
}
//Prototype DP
class ZombieLab {
	public static Zombie getclone(Zombie z) {
		return z.clone();
	}
}