package application;

import java.io.*;

import javafx.scene.image.ImageView;

public class Buckie extends Zombie implements Serializable{
	private final static long serialVersionUID = 14L;
	private int damage=1;
	Buckie(ImageView image){
		super(image);
		this.setName("Buckie");
		this.setSpeed(0.5f);
		this.setHealth(15);
	}
	public void hit(Plant t) {
		t.setHitpoints(t.getHitpoints()-damage);
	}
}
