package application;
import java.io.*;
import java.util.concurrent.TimeUnit;

import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;
//FlyWeight
public class App extends Application {
	public void animate(ImageView im) {
		TranslateTransition t= new TranslateTransition();
		t.setDuration(Duration.millis(15000));
		t.setNode(im);
		t.setByX(-500);
		t.setCycleCount(Timeline.INDEFINITE);
		t.setAutoReverse(false);
		t.play();
	}
	@Override
	public void start(Stage primaryStage) throws IOException {
		primaryStage.setTitle("Plants V/S Zombies");
		//Game object
		Game game = Game.getInstance();
		//Page1
		GridPane root= new GridPane();
		VBox buttons = new VBox(4);
		BackgroundSize s= new BackgroundSize(1000, 600, false, false, false,false);
		Background bg= new Background(new BackgroundImage(new Image("/resources/start.jpg"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,s));
		root.setBackground(bg);
		Background butt_bg= new Background(new BackgroundImage(new Image("/resources/wood1.png"),BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER, new BackgroundSize(100, 40,false,false,false,false)));
		Button butt1 = new Button("Start Game");
		butt1.setBackground(butt_bg);
		butt1.setTextFill(Paint.valueOf("#ffffff"));
		butt1.setPrefSize(100, 40);
		Button butt2 = new Button("Load Game");
		butt2.setBackground(butt_bg);
		butt2.setTextFill(Paint.valueOf("#ffffff"));
		butt2.setPrefSize(100, 40);
		Button butt3 = new Button("Help");
		butt3.setBackground(butt_bg);
		butt3.setTextFill(Paint.valueOf("#ffffff"));
		butt3.setPrefSize(100, 40);
		Button butt4 = new Button("Exit");
		butt4.setBackground(butt_bg);
		butt4.setTextFill(Paint.valueOf("#ffffff"));
		butt4.setPrefSize(100, 40);
		buttons.getChildren().add(butt1);
		buttons.getChildren().add(butt2);
		buttons.getChildren().add(butt3);
		buttons.getChildren().add(butt4);
		buttons.setAlignment(Pos.CENTER);
		root.add(buttons, 43, 30);
		Scene scene1 = new Scene(root,1000,600);
		//Login page
		GridPane login = new GridPane();
		login.gridLinesVisibleProperty();
		login.setBackground(bg);
		Label username = new Label("Enter Username");
		Button forward= new Button("Login");
		TextField user = new TextField();
		Scene scene2= new Scene(login,1000,600);
		login.setVgap(10);
		login.setHgap(10);
		root.setVgap(10);
		root.setHgap(10);
		login.add(username, 31, 30);
		login.add(user, 32, 30);
		login.add(forward, 32 , 31);
		butt4.setOnAction(e->{
			primaryStage.close();
		});
		butt1.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				primaryStage.setScene(scene2);
			}
		});
		
		//levelscreen
		GridPane lscreen = new GridPane();
		lscreen.setBackground(bg);
		Scene scene3 = new Scene(lscreen,1000,600);
		HBox levels = new HBox(5);
		Button level1 = new Button("Level 1");
		Button level2 = new Button("Level 2");
		Button level3 = new Button("Level 3");
		Button level4 = new Button("Level 4");
		Button level5 = new Button("Level 5");
		levels.getChildren().add(level1);
		levels.getChildren().add(level2);
		levels.getChildren().add(level3);
		levels.getChildren().add(level4);
		levels.getChildren().add(level5);
		lscreen.add(levels, 0, 0);
		Pane root2= new AnchorPane();
		forward.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				primaryStage.setScene(scene3);
			}
		});
		level1.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event) {
				Player p = new Player(user.getText());
				game.players.add(p);
				p.getLevel().setLevelScreen(root2,p,primaryStage);
				for(int i=0;i<p.getLevel().zimages.size();i++) {
					animate(p.getLevel().zimages.get(i));
				}
				Scene scene = new Scene(root2,1000,600);
				primaryStage.setScene(scene);
			}
		});
		//menuscreen
		
		primaryStage.setScene(scene1);
		primaryStage.show();
	}
//	public GridPane loadlevel1() {
//		GridPane root = new GridPane();
//		
//		
//	}
	public static void main(String[] args) {
		launch(args);
	}
}