package application;

import javafx.scene.image.ImageView;

public class Footie extends Zombie {
	private final static long serialVersionUID = 15L;
	private int damage=2;
	Footie(ImageView image){
		super(image);
		this.setName("Footie");
		this.setSpeed(0.8f);
		this.setHealth(20);
	}
	public void hit(Plant t) {
		t.setHitpoints(t.getHitpoints()-damage);
	}

}
