package application;

import javafx.scene.image.ImageView;

public class Walnut extends Plant {
	Walnut(ImageView image){
		super(image);
	}
	private static final long serialVersionUID = 2L;
	private int cost=50;
	
}
