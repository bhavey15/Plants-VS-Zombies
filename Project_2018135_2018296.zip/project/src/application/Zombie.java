package application;
import java.io.*;

import javafx.scene.image.ImageView;;
public abstract class Zombie implements Cloneable, Serializable {
	Zombie(ImageView image){
		this.image=image;
	}
	private static final long serialVersionUID = 20L;
	ImageView image;
	private int health;
	private int power;
	private float  speed;
	private String name;
	private int xpos;
	private int ypos;
	private int lane;
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getPower() {
		return power;
	}
	public void setPower(int power) {
		this.power = power;
	}
	public float getSpeed() {
		return speed;
	}
	public void setSpeed(float speed) {
		this.speed = speed;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getXpos() {
		return xpos;
	}
	public void setXpos(int xpos) {
		this.xpos = xpos;
	}
	public int getYpos() {
		return ypos;
	}
	public void setYpos(int ypos) {
		this.ypos = ypos;
	}
	public int getLane() {
		return lane;
	}
	public void setLane(int lane) {
		this.lane = lane;
	}
	public Zombie clone() {
		try {
			Zombie x =(Zombie)super.clone();
			x.image= new ImageView(this.image.getImage());
			return x;
		}
		catch(CloneNotSupportedException e) {
			return null;
		}
	}
	public abstract void hit(Plant t);
	
}
