package application;

import javafx.scene.image.ImageView;

public class Normie extends Zombie {
	private final static long serialVersionUID = 13L;
	private int damage=1;
	Normie(ImageView image){
		super(image);
		this.setName("Normie");
		this.setSpeed(0.5f);
		this.setHealth(10);
	}
	public void hit(Plant t) {
		t.setHitpoints(t.getHitpoints()-damage);
	}

}
