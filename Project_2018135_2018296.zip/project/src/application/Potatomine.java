package application;

import javafx.animation.Timeline;
import javafx.scene.image.ImageView;

public class Potatomine extends Plant {
	Potatomine(ImageView image){
		super(image);
	}
	private final static long serialVersionUID = 12L;
	private final int activateTime=4;
	private final int cost=75;
	private final int damage=10;
	private boolean hasExploded;
	public void activate() {
		
	}
	
	
}
