package application;

import javafx.scene.image.ImageView;

public class Sunflower extends Plant {
	Sunflower(ImageView image){
		super(image);
	}
	private final static long serialVersionUID = 11L;
	private final int cost=50;
	private int timer;
	private final int sunpoints=25;
	public void generateSun() {
		
	}
	
	
}
