package application;
import java.io.*;
import java.util.*;
//Implements Singleton DP
public class Game implements Serializable {
	private static final long serialVersionUID=21l;
	public static Game game = null;
	private Game() {
		
	}
	public static Game getInstance() {
		if(game==null)
			game= new Game();
		return game;
	}
	ArrayList<Player> players = new ArrayList<Player>();
	public void serialize(String fname, int index) throws IOException {
		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(new FileOutputStream(fname));
			out.writeObject(this.players.get(index));
		}
		finally {
			if(out!=null)
				out.close();
		}
	}
	public Player deserialize(String fname) throws IOException, ClassNotFoundException {
		ObjectInputStream in = null;
		try {
			in = new ObjectInputStream(new FileInputStream(fname));
			Player p = (Player)in.readObject();
			return p;
		}
		finally {
			if(in!=null)
				in.close();
		}
	}
}
