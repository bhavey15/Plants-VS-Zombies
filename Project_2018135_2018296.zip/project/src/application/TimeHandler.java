package application;

import javafx.animation.KeyValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.image.ImageView;

public class TimeHandler implements EventHandler<ActionEvent> {
	ImageView i;
	int[] a;
	
	TimeHandler(ImageView v, int[] arr) {
		this.i = v;
		this.a = arr;
	}

	@Override
	public void handle(ActionEvent event) {
		// TODO Auto-generated method stub
		i.setVisible(true);
		for(int i=0;i<5;i++) {
			this.a[i]=1;
		}

		}

}
