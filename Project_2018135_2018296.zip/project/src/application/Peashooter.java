package application;

import javafx.scene.image.ImageView;

public class Peashooter extends Plant {
	Peashooter(ImageView image){
		super(image);
	}
	private final static long serialVersionUID = 1L;
	private final int cost=100;
	private final int damage=2;
	public int getDamage() {
		return damage;
	}
	public int getCost() {
		return cost;
	}
	public Peashooter clone(Object o) {
		try {
			Peashooter x = (Peashooter)super.clone();
			return x;
		}
		catch(CloneNotSupportedException e) {
			return null;
		}
	}
	public void shootPea(Zombie z) {
		
	}
	@Override
	public String toString() {
		return null;
		
	}
	
}
