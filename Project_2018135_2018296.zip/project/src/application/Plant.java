package application;

import java.io.*;
import java.util.*;

import javafx.scene.image.ImageView;

public abstract class Plant implements Cloneable, Serializable{
	Plant(ImageView image){
		this.image=image;
	}
	ImageView image;
	private final static long serialVersionUID = 10L;
	private int posX;
	private int posY;
	private int hitpoints;
	public int getPosX() {
		return posX;
	}
	public void setPosX(int posX) {
		this.posX = posX;
	}
	public int getPosY() {
		return posY;
	}
	public void setPosY(int posY) {
		this.posY = posY;
	}
	public int getHitpoints() {
		return hitpoints;
	}
	public void setHitpoints(int hitpoints) {
		this.hitpoints = hitpoints;
	}
	public boolean isPlantDead() {
		if(this.hitpoints==0)
			return true;
		else
			return false;
	}
//	@Override
	public Plant clone(Object o) {
		try {
			Plant x = (Plant)super.clone();
			return x;
		}
		catch(CloneNotSupportedException e) {
			return null;
		}
	}
}

